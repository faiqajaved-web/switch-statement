#include<iostream>
using namespace std;
int main ()
{
  int age;
cout << "Enter age:";
cin >> age;
switch (age >= 18)
{
       case 1:cout << "Person is eligible for driving license";
       break;
       case 0:
            cout << "Person is not eligible for driving license";
            break;
            }
            return 0;
}



    
  

  

          
  Footer

  
    


    
