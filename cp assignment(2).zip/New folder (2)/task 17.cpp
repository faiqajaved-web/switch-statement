#include<iostream>
using namespace std;
int main ()
{
  int number;
cout << "Enter number:";
cin >> number;
switch (number == 100)
{
   case 1:
cout << "Number is equal to 100";
break;
case 0:
cout << "Number is not equal to 100";
break;
}
return 0;
}    
