#include<iostream>
using namespace std;
int main ()
{
  int marks;
cout << "Enter marks:";
cin >> marks;
switch (marks > 80)
{
case 1:
cout << "Marks are above 80";
break;
case 0:
cout << "Marks are not above 80";
break;
}
return 0;
}
