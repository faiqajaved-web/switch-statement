#include<iostream>
using namespace std;
int main ()
{
  int num;
cin >> num;
switch (num < 0)
{
case 1:
cout << "Number is negative";
break;
case 0:
cout << "Number is not negative";
break;
}
return 0;
}
