#include<iostream>
using namespace std;
int main ()
{
  int number;
cout << "Enter a number";
cin >> number;
switch (number > 10)
{
case 1:
     cout << "Number is greater than 10";
break;
case 0:
cout << "Number is not greater than 10";
break;
}
return 0;
}
