#include<iostream>
using namespace std;
int main ()
{
  int age;
cout << "Enter your age:";
cin >> age;
switch (age >= 18)
{
       case 1:
cout << "Eligible to vote";
break;
case 0:
cout << "Not eligible to vote";
break;
}
return 0;
}
