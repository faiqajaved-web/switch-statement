#include<iostream>
using namespace std;
int main ()
{
  int number;
cout << "Enter number:";
cin >> number;
switch (number % 10 == 0)
{
       case 1:
cout << "Number is divisible by 10";
break;
case 0:
cout << "Number is not divisible by 10";
break;
}
return 0;
}
