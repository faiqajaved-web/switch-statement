#include<iostream>
using namespace std;
int main ()
{
  int marks;
cout << "Enter marks:";
cin >> marks;
switch (marks >= 40)
{
case 1:
     cout << "Student has passed.";
break;
case 0;
cout << "Student has failed.";
breaks;
}
return 0;
}
