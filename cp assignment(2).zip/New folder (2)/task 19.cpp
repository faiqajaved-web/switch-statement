#include<iostream>
using namespace std;
int main ()
{
  int number;
cout << "Enter number:";
cin >> number;
switch (number > 50)
{
case 1:
cout << "Number is greater than 50";
break;
case 0:
cout << "Number is not greater than 50";
break;
}
return 0;
}
