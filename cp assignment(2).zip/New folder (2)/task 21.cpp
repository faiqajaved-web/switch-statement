#include<iostream>
using namespace std;
int main ()
{
  int price;
cout << "Enter product price:";
cin >> price;
switch (price > 5000)
{
case 1:
cout << "Price is above 5000";
break;
case 0:
cout << "Price is not above 5000";
break;
}
return 0;
}
