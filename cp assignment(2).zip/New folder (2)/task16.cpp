#include<iostream>
using namespace std;
int main ()
{
  int num;
cout << "Enter a number:";
cin >> num;
switch (num > 0)
{
case 1:
cout << "Number is positive";
break;
case 0:
cout << "Number is zero or negative";
}
return 0;
}
