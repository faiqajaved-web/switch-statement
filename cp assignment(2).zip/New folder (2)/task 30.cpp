#include<iostream>
using namespace std;
int main ()
{
  int age;
cout << "Enter age:";
cin >> age;
switch (age > 60)
{
case 1:
     break;
     case 0:
          cout << "Age is not above 60";
          break;
          }
          return 0;
}
