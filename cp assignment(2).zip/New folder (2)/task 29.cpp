#include<iostream>
using namespace std;
int main ()
{
  int temperature;
cout << "Enter temperature:";
cin >> temperature;
switch (temperature > 30)
{
case 1:
cout << "Temperature is above 30\B0C";
break;
case 0:
cout << "Temperature is not above 30\B0C";
break;
}
return 0;
}
